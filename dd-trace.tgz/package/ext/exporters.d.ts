declare const exporters: {
  LOG: 'log',
  AGENT: 'agent',
  AGENTLESS: 'agentless',
  DATADOG: 'datadog',
  AGENT_PROXY: 'agent_proxy',
  JEST_WORKER: 'jest_worker',
  CUCUMBER_WORKER: 'cucumber_worker',
  MOCHA_WORKER: 'mocha_worker',
  PLAYWRIGHT_WORKER: 'playwright_worker',
  VITEST_WORKER: 'vitest_worker'
}

export = exporters
