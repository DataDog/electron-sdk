'use strict'

const CompositePlugin = require('../../dd-trace/src/plugins/composite')
const Http2ServerPlugin = require('./server')
const Http2ClientPlugin = require('./client')

class Http2Plugin extends CompositePlugin {
  static id = 'http2'
  static get plugins () {
    return {
      server: Http2ServerPlugin,
      client: Http2ClientPlugin,
    }
  }
}

module.exports = Http2Plugin
