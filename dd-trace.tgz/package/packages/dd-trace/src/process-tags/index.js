'use strict'

const path = require('node:path')

const CURRENT_WORKING_DIRECTORY = process.cwd()
const ENTRYPOINT_PATH = require.main?.filename || ''

// $ cd /foo/bar && node baz/banana.js
// entrypoint.workdir = bar
// entrypoint.name = banana
// entrypoint.type = script
// entrypoint.basedir = baz
// package.json.name = <from package.json>

/**
 * Sanitize a process tag value
 *
 * @param {string} value
 * @returns {string}
 */
function sanitize (value) {
  return String(value)
    .toLowerCase()
    .replaceAll(/[^a-zA-Z0-9/_.-]+/g, '_')
}

function buildProcessTags (config) {
  // Lazy load pkg to avoid issues with require.main during test initialization
  const pkg = require('../pkg')

  // this list is sorted alphabetically for consistent serialization
  const tags = [
    // the parent directory name of the entrypoint script, e.g. /foo/bar/baz/banana.js -> baz
    ['entrypoint.basedir', ENTRYPOINT_PATH === '' ? undefined : path.basename(path.dirname(ENTRYPOINT_PATH))],

    // the entrypoint script filename without the extension, e.g. /foo/bar/baz/banana.js -> banana
    ['entrypoint.name', path.basename(ENTRYPOINT_PATH, path.extname(ENTRYPOINT_PATH)) || undefined],

    // always script for JavaScript applications
    ['entrypoint.type', 'script'],

    // last segment of the current working directory, e.g. /foo/bar/baz/ -> baz
    ['entrypoint.workdir', path.basename(CURRENT_WORKING_DIRECTORY) || undefined],

    // the .name field from the application's package.json
    ['package.json.name', pkg.name || undefined],
  ]

  // If config dependent tags keep growing, we should consider moving this into a function
  if (config?.isServiceNameInferred) {
    tags.push(['svc.auto', config.service])
  } else if (config) {
    tags.push(['svc.user', true])
  }

  const tagsArray = []
  const tagsObject = {}

  for (const [key, value] of tags) {
    if (value !== undefined) {
      const sanitizedValue = sanitize(value)
      tagsArray.push(`${key}:${sanitizedValue}`)
      tagsObject[key] = sanitizedValue
    }
  }

  processTags.tags = tags
  processTags.serialized = tagsArray.join(',')
  processTags.tagsObject = tagsObject
  processTags.tagsArray = tagsArray
}

// Singleton with constant defaults so pre-init reads don't blow up
const processTags = module.exports = {
  /**
   * @param {import('../config/config-base')} config
   */
  initialize (config) {
    // check if one of the properties added during build exist and if so return
    if (processTags.tags) return
    buildProcessTags(config)
  },

  TRACING_FIELD_NAME: '_dd.tags.process',
  DSM_FIELD_NAME: 'ProcessTags',
  PROFILING_FIELD_NAME: 'process_tags',
  DYNAMIC_INSTRUMENTATION_FIELD_NAME: 'process_tags',
  TELEMETRY_FIELD_NAME: 'process_tags',
  REMOTE_CONFIG_FIELD_NAME: 'process_tags',
  CRASH_TRACKING_FIELD_NAME: 'process_tags',
  CLIENT_TRACE_STATISTICS_FIELD_NAME: 'ProcessTags',
  sanitize,
}
