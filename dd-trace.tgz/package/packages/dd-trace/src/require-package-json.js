'use strict'

const path = require('path')
const fs = require('fs')

/**
 * Given a package name and a module to start from, find a package's
 * package.json file, parses it, and returns the result.
 *
 * Equivalent to require(`${name}/package.json`) prior to Node 12.
 *
 * @typedef { import('module').Module } Module
 * @param {string} name
 * @param {Module} module
 * @returns {object} The parsed package.json
 */
function requirePackageJson (name, module) {
  if (path.isAbsolute(name)) {
    const candidate = path.join(name, 'package.json')
    return JSON.parse(fs.readFileSync(candidate, 'utf8'))
  }
  for (const modulePath of module.paths) {
    const candidate = path.join(modulePath, name, 'package.json')
    // fs.existsSync is faster than fs.readFileSync due to not throwing an error if the file does not exist.
    // The race condition should also not matter here as the time window is very small.
    if (fs.existsSync(candidate)) {
      try {
        return JSON.parse(fs.readFileSync(candidate, 'utf8'))
      } catch {
        continue
      }
    }
  }
  throw new Error(`could not find ${name}/package.json`)
}

module.exports = requirePackageJson
