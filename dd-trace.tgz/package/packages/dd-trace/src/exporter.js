'use strict'

const fs = require('fs')
const exporters = require('../../../ext/exporters')
const { getEnvironmentVariable } = require('../../dd-trace/src/config/helper')
const constants = require('./constants')

module.exports = function getExporter (name) {
  switch (name) {
    case exporters.ELECTRON:
      return require('./exporters/electron')
    case exporters.LOG:
      return require('./exporters/log')
    case exporters.AGENT:
      return require('./exporters/agent')
    case exporters.AGENTLESS:
      return require('./exporters/agentless')
    case exporters.DATADOG:
      return require('./ci-visibility/exporters/agentless')
    case exporters.AGENT_PROXY:
      return require('./ci-visibility/exporters/agent-proxy')
    case exporters.JEST_WORKER:
    case exporters.CUCUMBER_WORKER:
    case exporters.MOCHA_WORKER:
    case exporters.PLAYWRIGHT_WORKER:
    case exporters.VITEST_WORKER:
      return require('./ci-visibility/exporters/test-worker')
    default: {
      const inAWSLambda = getEnvironmentVariable('AWS_LAMBDA_FUNCTION_NAME') !== undefined
      const usingAgent = inAWSLambda && (
        fs.existsSync(constants.DATADOG_LAMBDA_EXTENSION_PATH) ||
        fs.existsSync(constants.DATADOG_MINI_AGENT_PATH)
      )
      return require(inAWSLambda && !usingAgent ? './exporters/log' : './exporters/agent')
    }
  }
}
