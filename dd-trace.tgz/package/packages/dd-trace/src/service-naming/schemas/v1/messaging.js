'use strict'

const { identityService } = require('../util')

const amqpInbound = {
  opName: () => 'amqp.process',
  serviceName: identityService,
}

const amqpOutbound = {
  opName: () => 'amqp.send',
  serviceName: identityService,
}

const messaging = {
  producer: {
    amqplib: amqpOutbound,
    amqp10: amqpOutbound,
    'azure-service-bus': {
      opName: () => 'azure.servicebus.send',
      serviceName: identityService,
    },
    'azure-event-hubs': {
      opName: () => 'azure.eventhubs.send',
      serviceName: identityService,
    },
    'electron:ipc:main:send': {
      opName: () => 'electron.main.send',
      serviceName: identityService,
    },
    'electron:ipc:renderer:send': {
      opName: () => 'electron.renderer.send',
      serviceName: identityService,
    },
    'google-cloud-pubsub': {
      opName: () => 'gcp.pubsub.send',
      serviceName: identityService,
    },
    kafkajs: {
      opName: () => 'kafka.send',
      serviceName: identityService,
    },
    'confluentinc-kafka-javascript': {
      opName: () => 'kafka.send',
      serviceName: identityService,
    },
    rhea: amqpOutbound,
    sqs: {
      opName: () => 'aws.sqs.send',
      serviceName: identityService,
    },
    sns: {
      opName: () => 'aws.sns.send',
      serviceName: identityService,
    },
    bullmq: {
      opName: () => 'bullmq.add',
      serviceName: identityService,
    },
  },
  consumer: {
    amqplib: amqpInbound,
    amqp10: amqpInbound,
    'electron:ipc:main:receive': {
      opName: () => 'electron.main.receive',
      serviceName: identityService,
    },
    'electron:ipc:main:handle': {
      opName: () => 'electron.main.handle',
      serviceName: identityService,
    },
    'electron:ipc:renderer:receive': {
      opName: () => 'electron.renderer.receive',
      serviceName: identityService,
    },
    'google-cloud-pubsub': {
      opName: () => 'gcp.pubsub.process',
      serviceName: identityService,
    },
    kafkajs: {
      opName: () => 'kafka.process',
      serviceName: identityService,
    },
    'confluentinc-kafka-javascript': {
      opName: () => 'kafka.process',
      serviceName: identityService,
    },
    rhea: amqpInbound,
    sqs: {
      opName: () => 'aws.sqs.process',
      serviceName: identityService,
    },
    bullmq: {
      opName: () => 'bullmq.processJob',
      serviceName: identityService,
    },
  },
  client: {
    amqplib: {
      opName: () => 'amqp.command',
      serviceName: identityService,
    },
    'google-cloud-pubsub': {
      opName: () => 'gcp.pubsub.request',
      serviceName: identityService,
    },
  },
}

module.exports = messaging
