'use strict'

// TODO: reorder all this, it's a mess
module.exports = {
  HTTP_INCOMING_BODY: 'server.request.body',
  HTTP_INCOMING_QUERY: 'server.request.query',
  HTTP_INCOMING_HEADERS: 'server.request.headers.no_cookies',
  // TODO: 'server.request.trailers',
  HTTP_INCOMING_URL: 'server.request.uri.raw',
  HTTP_INCOMING_METHOD: 'server.request.method',
  HTTP_INCOMING_PARAMS: 'server.request.path_params',
  HTTP_INCOMING_COOKIES: 'server.request.cookies',
  HTTP_INCOMING_RESPONSE_CODE: 'server.response.status',
  HTTP_INCOMING_RESPONSE_HEADERS: 'server.response.headers.no_cookies',
  // TODO: 'server.response.trailers',
  HTTP_INCOMING_GRAPHQL_RESOLVERS: 'graphql.server.all_resolvers',
  HTTP_INCOMING_GRAPHQL_RESOLVER: 'graphql.server.resolver',

  HTTP_INCOMING_RESPONSE_BODY: 'server.response.body',

  HTTP_CLIENT_IP: 'http.client_ip',

  USER_ID: 'usr.id',
  USER_LOGIN: 'usr.login',
  USER_SESSION_ID: 'usr.session_id',

  WAF_CONTEXT_PROCESSOR: 'waf.context.processor',

  HTTP_OUTGOING_URL: 'server.io.net.url',
  HTTP_OUTGOING_METHOD: 'server.io.net.request.method',
  HTTP_OUTGOING_HEADERS: 'server.io.net.request.headers',
  HTTP_OUTGOING_RESPONSE_STATUS: 'server.io.net.response.status',
  HTTP_OUTGOING_RESPONSE_HEADERS: 'server.io.net.response.headers',
  HTTP_OUTGOING_RESPONSE_BODY: 'server.io.net.response.body',

  FS_OPERATION_PATH: 'server.io.fs.file',

  DB_STATEMENT: 'server.db.statement',
  DB_SYSTEM: 'server.db.system',

  EXEC_COMMAND: 'server.sys.exec.cmd',
  SHELL_COMMAND: 'server.sys.shell.cmd',

  LOGIN_SUCCESS: 'server.business_logic.users.login.success',
  LOGIN_FAILURE: 'server.business_logic.users.login.failure',

  PAYMENT_CREATION: 'server.business_logic.payment.creation',
  PAYMENT_SUCCESS: 'server.business_logic.payment.success',
  PAYMENT_FAILURE: 'server.business_logic.payment.failure',
  PAYMENT_CANCELLATION: 'server.business_logic.payment.cancellation',
}
