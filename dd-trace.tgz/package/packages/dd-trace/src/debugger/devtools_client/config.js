'use strict'

const { workerData: { config: parentConfig, parentThreadId, configPort } } = require('node:worker_threads')
const { getAgentUrl } = require('../../agent/url')
const processTags = require('../../process-tags')
const log = require('./log')

processTags.initialize()

const config = module.exports = {
  ...parentConfig,
  parentThreadId,
  maxTotalPayloadSize: 5 * 1024 * 1024, // 5MB
}

updateConfig(parentConfig)

configPort.on('message', updateConfig)
configPort.on('messageerror', (err) =>
  log.error('[debugger:devtools_client] received "messageerror" on config port', err)
)

function updateConfig (updates) {
  config.url = getAgentUrl(updates)
  config.dynamicInstrumentation.captureTimeoutNs = BigInt(updates.dynamicInstrumentation.captureTimeoutMs) * 1_000_000n
}
