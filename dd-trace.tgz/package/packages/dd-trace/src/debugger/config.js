'use strict'

module.exports = function getDebuggerConfig (config, inputPath) {
  return {
    commitSHA: config.commitSHA,
    debug: config.debug,
    dynamicInstrumentation: config.dynamicInstrumentation,
    hostname: config.hostname,
    logLevel: config.logLevel,
    port: config.port,
    propagateProcessTags: config.propagateProcessTags,
    repositoryUrl: config.repositoryUrl,
    runtimeId: config.tags['runtime-id'],
    service: config.service,
    url: config.url?.toString(),
    inputPath,
  }
}
