'use strict'
const request = require('../../../exporters/common/request')
const log = require('../../../log')
const { safeJSONStringify } = require('../../../exporters/common/util')
const { JSONEncoder } = require('../../encode/json-encoder')
const { getValueFromEnvSources } = require('../../../config/helper')
const { DEBUGGER_INPUT_V1 } = require('../../../debugger/constants')

const BaseWriter = require('../../../exporters/common/writer')

// Writer used by the integration between Dynamic Instrumentation and Test Visibility
// It is used to encode and send logs to both the logs intake directly and the
// `/debugger/v1/input` endpoint in the agent, which is a proxy to the logs intake.
class DynamicInstrumentationLogsWriter extends BaseWriter {
  // TODO: what's a good value for timeout for the logs intake?
  constructor ({ url, timeout = 15_000, isAgentProxy = false }) {
    super(...arguments)
    this._url = url
    this._encoder = new JSONEncoder()
    this._isAgentProxy = isAgentProxy
    this.timeout = timeout
  }

  _sendPayload (data, _, done) {
    const options = {
      path: '/api/v2/logs',
      method: 'POST',
      headers: {
        'dd-api-key': getValueFromEnvSources('DD_API_KEY'),
        'Content-Type': 'application/json',
      },
      timeout: this.timeout,
      url: this._url,
    }

    if (this._isAgentProxy) {
      delete options.headers['dd-api-key']
      options.path = DEBUGGER_INPUT_V1
    }

    // eslint-disable-next-line eslint-rules/eslint-log-printf-style
    log.debug(() => `Request to the logs intake: ${safeJSONStringify(options)}`)

    request(data, options, (err, res) => {
      if (err) {
        log.error('Error sending DI logs payload', err)
        done()
        return
      }
      log.debug('Response from the logs intake:', res)
      done()
    })
  }
}

module.exports = DynamicInstrumentationLogsWriter
