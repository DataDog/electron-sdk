'use strict'

const CompositePlugin = require('../../dd-trace/src/plugins/composite')

const WSServerPlugin = require('./server')
const WSProducerPlugin = require('./producer')
const WSReceiverPlugin = require('./receiver')
const WSClosePlugin = require('./close')

class WSPlugin extends CompositePlugin {
  static get id () { return 'ws' }
  static get plugins () {
    return {
      server: WSServerPlugin,
      producer: WSProducerPlugin,
      receiver: WSReceiverPlugin,
      close: WSClosePlugin,
    }
  }

  configure (config) {
    if (!config.traceWebsocketMessagesEnabled) {
      super.configure(false)
      return
    }
    return super.configure(config)
  }
}

module.exports = WSPlugin
