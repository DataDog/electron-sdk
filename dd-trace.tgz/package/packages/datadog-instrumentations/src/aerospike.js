'use strict'

const tracingChannel = require('dc-polyfill').tracingChannel

const shimmer = require('../../datadog-shimmer')
const {
  addHook,
} = require('./helpers/instrument')

const ch = tracingChannel('apm:aerospike:command')

function wrapCreateCommand (createCommand) {
  if (typeof createCommand !== 'function') return createCommand

  return function commandWithTrace () {
    const CommandClass = createCommand.apply(this, arguments)

    if (!CommandClass) return CommandClass

    shimmer.wrap(CommandClass.prototype, 'process', wrapProcess)

    return CommandClass
  }
}

function wrapProcess (process) {
  return function (...args) {
    const cb = args[0]
    if (typeof cb !== 'function') return process.apply(this, args)

    const ctx = {
      commandName: this.constructor.name,
      commandArgs: this.args,
      clientConfig: this.client.config,
    }

    return ch.traceCallback(process, -1, ctx, this, ...args)
  }
}

addHook({
  name: 'aerospike',
  file: 'lib/commands/command.js',
  versions: ['4', '5', '6'],
},
commandFactory => {
  return shimmer.wrapFunction(commandFactory, f => wrapCreateCommand(f))
})
