'use strict'

const KafkajsPlugin = require('../../datadog-plugin-kafkajs/src/index')
const ProducerPlugin = require('./producer')
const ConsumerPlugin = require('./consumer')
const BatchConsumerPlugin = require('./batch-consumer')

class ConfluentKafkaJsPlugin extends KafkajsPlugin {
  /**
   * @override
   */
  static id = 'confluentinc-kafka-javascript'
  /**
   * @override
   */
  static get plugins () {
    return {
      producer: ProducerPlugin,
      consumer: ConsumerPlugin,
      batchConsumer: BatchConsumerPlugin,
    }
  }
}

module.exports = ConfluentKafkaJsPlugin
