'use strict'

const CompositePlugin = require('../../dd-trace/src/plugins/composite')
const ProducerPlugin = require('./producer')
const ConsumerPlugin = require('./consumer')
const ClientPlugin = require('./client')

// TODO: Consider splitting channels for publish/receive in the instrumentation.
class AmqplibPlugin extends CompositePlugin {
  static id = 'amqplib'
  static get plugins () {
    return {
      producer: ProducerPlugin,
      consumer: ConsumerPlugin,
      client: ClientPlugin,
    }
  }
}

module.exports = AmqplibPlugin
